﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string name, params string[] fieldsToFind) 
        {
            Type type = Type.GetType(name);
            FieldInfo[] allFields = type.GetFields(BindingFlags.Public|BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Static);
            StringBuilder text = new StringBuilder();

            object classInstance = Activator.CreateInstance(type, new object[] { });
            foreach (var field in allFields.Where(x => fieldsToFind.Contains(x.Name)))
            {
                text.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }
            Console.WriteLine($"Class under investigation: {name}");
            return text.ToString().Trim();
        }
    }
}
