﻿using Bakery.Models.BakedFoods;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables.Contracts;
using Bakery.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bakery.Models.Tables
{
    public abstract class Table : ITable
    {
        public Table(int tableNumber, int capacity, decimal pricePerPerson)
        {
            TableNumber = tableNumber;
            Capacity = capacity;
            PricePerPerson = pricePerPerson;
            FoodOrders = new List<IBakedFood>();
            DrinkOrders = new List<IDrink>();
        }
        public int TableNumber { get; private set; }

        private List<IBakedFood> FoodOrders;
        private List<IDrink> DrinkOrders;

        private int capacity;

        public int Capacity
        {
            get { return capacity; }
            protected set 
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidTableCapacity);
                }
                capacity = value;
            }
        }
        private int numberOfPeople;

        public int NumberOfPeople
        {
            get { return numberOfPeople; }
            protected set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidNumberOfPeople);
                }
                numberOfPeople = value;
            }
        }

        public decimal PricePerPerson { get; private set; }

        public bool IsReserved { get; private set; }

        public decimal Price => NumberOfPeople*PricePerPerson;

        public void Clear()
        {
            DrinkOrders.Clear();
            FoodOrders.Clear();
            IsReserved = false;
        }

        public decimal GetBill()
        {
            decimal bill = 0;
            foreach (var drink in DrinkOrders)
            {
                bill += drink.Price;
            }
            foreach (var food in FoodOrders)
            {
                bill += food.Price;
            }
            return bill;
        }

        public string GetFreeTableInfo()
        {
            StringBuilder text = new StringBuilder();
            text.AppendLine($"Table: {TableNumber}");
            text.AppendLine($"Type: {this.GetType().Name}");
            text.AppendLine($"Capacity: {Capacity}");
            text.AppendLine($"Price per Person: {PricePerPerson}");
            return text.ToString().Trim();
        }

        public void OrderDrink(IDrink drink)
        {
            DrinkOrders.Add(drink);
        }

        public void OrderFood(IBakedFood food)
        {
            FoodOrders.Add(food);
        }

        public void Reserve(int numberOfPeople)
        {
            IsReserved = true;
            NumberOfPeople = numberOfPeople;
        }
    }
}
