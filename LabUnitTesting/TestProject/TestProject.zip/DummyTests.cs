﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Tests
{
    [TestFixture]
    public class DummyTests
    {
        private Dummy dummy;
        private Axe axe;
        private Hero hero;
        [SetUp]
        public void Initialize()
        {
            dummy = new Dummy(17, 2);
            axe = new Axe(5, 10);
            hero = new Hero("Gosho");
        }
        [Test]
        public void DummyLosesHealthIfAttacked() 
        {
            axe.Attack(dummy);

            Assert.That(dummy.Health, Is.EqualTo(12));
        }
        [Test]
        public void DeadDummyThrowsExeption()
        {
            axe.Attack(dummy);
            axe.Attack(dummy);
            axe.Attack(dummy);
            axe.Attack(dummy);

            Assert.That(() => axe.Attack(dummy), Throws.InvalidOperationException.With.Message.EqualTo("Dummy is dead."));
        }
        [Test]
        public void DeadDummyCangiveXP()
        {
            hero.Attack(dummy);
            hero.Attack(dummy);

            Assert.That(hero.Experience, Is.EqualTo(2));
        }
        [Test]
        public void AliveDummyCantGiveXp() 
        {
            Assert.That(() => dummy.GiveExperience(), Throws.InvalidOperationException.With.Message.EqualTo("Target is not dead."));
        }
    }
}
