﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            List<int> banned = new List<int>();
            List<string> list = new List<string>();
            while (input != "End")
            {
                var splitted = input.Split();
                if (splitted.Length == 2)
                {
                    list.Add(splitted[1]);
                }
                else
                {
                    list.Add(splitted[2]);
                }
                input = Console.ReadLine();
            }
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine(string.Join("\n", list.Where(x => x.EndsWith(number.ToString()))));
        }
    }
}
