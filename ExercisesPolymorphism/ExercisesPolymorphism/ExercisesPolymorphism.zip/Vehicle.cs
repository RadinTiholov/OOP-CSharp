﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExercisesPolymorphism
{
    public abstract class Vehicle
    {
        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }
        public double FuelQuantity { get; internal set; }
        public virtual double FuelConsumption  { get; }
        public virtual void Refuel(double liters) 
        {
            this.FuelQuantity += liters;
        }
        public void Drive(double distance) 
        {
            if (CanDrive(distance))
            {
                this.FuelQuantity -= distance * FuelConsumption;
            }
            else
            {
                throw new Exception("It doesn't have enough fuel!");
            }
        }

        private bool CanDrive(double distance)
        {
            if (distance * FuelConsumption <= FuelQuantity)
            {
                return true;
            }
            return false;
        }
    }
}
