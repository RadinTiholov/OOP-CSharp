﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface INetSurfable
    {
        string SurfTheWeb(string site);
    }
}
